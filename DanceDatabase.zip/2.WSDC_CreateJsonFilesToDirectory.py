import requests
import json
import pyodbc
import time
import threading
import queue
import os
import sys
import xml.etree.ElementTree as ET

#start time
start_time = time.time()

#num threads
num_threads = 10

#set directory
curDirectory = os.getcwd()
configFile = curDirectory + '\ConfigurationFile.xml'
tree = ET.parse(configFile)
root = tree.getroot()

#get config values
API_url = root.find(".//WcsURL").text
database = root.find(".//DatabaseName").text
server = root.find(".//SQLInstanceName").text
jsonPath = curDirectory + '\\' + root.find(".//JsonFolder").text + '\\'

#build connection object
cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes')
cursor = cnxn.cursor()
cursor.execute("SELECT WSCID FROM dbo.DimDancer")
dancerids = cursor.fetchall()

def getDancerName(dancerid):
    #while True:
    request = requests.post(API_url, data={'q': dancerid})
    try:
        dancerinfo = request.json()
        if dancerinfo['type'] == 'dancer' and len(dancerinfo['placements']) > 0:
            firstname = dancerinfo['dancer']['first_name']
            lastname = dancerinfo['dancer']['last_name']
            wscid = dancerinfo['dancer']['wscid']
            fileName = "{filePath}{id}_{firstname}{lastname}.json".format(filePath=jsonPath,id=wscid,firstname=firstname,lastname=lastname)
            with open(fileName, 'w+') as f:
                json.dump(dancerinfo, f)
    except :
        pass

def worker():
    while True:
        item = q.get()
        getDancerName(item)
        q.task_done()


q = queue.Queue()
for dancerid in dancerids:
    q.put(dancerid)

for i in range(num_threads):
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()

q.join()

print("--- %s seconds ---" % (time.time() - start_time))

