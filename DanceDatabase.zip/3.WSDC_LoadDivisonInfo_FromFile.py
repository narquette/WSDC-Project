import json
import requests
import pyodbc
from pathlib import Path
import time
import threading
import queue
import os, sys
import xml.etree.ElementTree as ET

# start time
start_time = time.time()

# num threads
num_threads = 10

#set directory
curDirectory = os.getcwd()
configFile = curDirectory + '\ConfigurationFile.xml'
tree = ET.parse(configFile)
root = tree.getroot()

#get config values
database = root.find(".//DatabaseName").text
server = root.find(".//SQLInstanceName").text

#build connection object
cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes')
cursor = cnxn.cursor()
cursor.execute("SELECT WSCID FROM dbo.DimDancer")
dancerids = cursor.fetchall()

# file root
fileRoot = curDirectory + '\\' + root.find(".//JsonFolder").text + '\\'
pathlist = Path(fileRoot).glob('**/*.json')

# events dictionary to use for loading
divisions =  {}

def getEventInfoFile(filePath):
    with open(filePath,'r+') as info:
        json_data = info.read()
        dancerinfo = json.loads(json_data)

    try:
        if dancerinfo['type'] == 'dancer' and len(dancerinfo['placements']) > 0:
            placement = dancerinfo['placements']
            for p in placement['West Coast Swing']:
                divid, divname, divabb = p['division']['id'], p['division']['name'], p['division']['abbreviation']
                divisions[divid] = [divname, divabb]
    except:
        pass

def worker():
    while True:
        item = q.get()
        getEventInfoFile(item)
        q.task_done()

q = queue.Queue()
for path in pathlist:
    q.put(path)

for i in range(num_threads):
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()

q.join()

for key, value in divisions.items():
    divid = key
    divname = value[0]
    divabb = value[1]

    query = "INSERT INTO dbo.dimDivision (DivisionId, Name, Abbreviation) VALUES (?,?,?)"
    try:
        cursor.execute(query, divid, divname, divabb)
        cursor.commit()
    except :
        print(query, divid, divname, divabb)
        pass

