import json
import requests
import pyodbc
from pathlib import Path
import time
import threading
import queue
import os, sys
import xml.etree.ElementTree as ET

# start time
start_time = time.time()

# num threads
num_threads = 10

#set directory
curDirectory = os.getcwd()
configFile = curDirectory + '\ConfigurationFile.xml'
tree = ET.parse(configFile)
root = tree.getroot()

#get config values
database = root.find(".//DatabaseName").text
server = root.find(".//SQLInstanceName").text

#build connection object
cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes')
cursor = cnxn.cursor()
cursor.execute("SELECT WSCID FROM dbo.DimDancer")
dancerids = cursor.fetchall()

# file root
fileRoot = curDirectory + '\\' + root.find(".//JsonFolder").text + '\\'
pathlist = Path(fileRoot).glob('**/*.json')

# events dictionary to use for loading
events =  {}

def getEventInfoFile(filePath):

    with open(filePath,'r+') as info:
        json_data = info.read()
        dancerinfo = json.loads(json_data)

    try:
        if dancerinfo['type'] == 'dancer' and len(dancerinfo['placements']) > 0:
            placement = dancerinfo['placements']
            for p in placement['West Coast Swing']:
                comps = p['competitions']
                for c in comps:
                    eventid, eventname, location = c['event']['id'], c['event']['name'], c['event']['location']
                    events[eventid] = [eventname, location]

    except:
        pass


def worker():
    while True:
        item = q.get()
        getEventInfoFile(item)
        q.task_done()


q = queue.Queue()
for path in pathlist:
    q.put(path)

for i in range(num_threads):
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()

q.join()

for key, value in events.items():
    eventid = key
    name = value[0]
    location = value[1].split(',')
    city = location[0].strip()
    state = location[1].strip()
    if len(state) == 2:
        country = "USA"
    elif state == "Texas":
        state = "TX"
        country = "USA"
    else :
        country = state
        state = "International"
    query = "INSERT INTO dbo.dimEvent (EventId, Name, City, State, Country) VALUES (?,?,?,?,?)"
    try:
        cursor.execute(query, eventid, name, city, state, country)
        cursor.commit()
    except :
        pass


print("--- %s seconds ---" % (time.time() - start_time))

