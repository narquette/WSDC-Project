import json
import requests
import pyodbc
from pathlib import Path
import time
import threading
import queue
import os, sys
import xml.etree.ElementTree as ET

# start time
start_time = time.time()

# num threads
num_threads = 10

#set directory
curDirectory = os.getcwd()
configFile = curDirectory + '\ConfigurationFile.xml'
tree = ET.parse(configFile)
root = tree.getroot()

#get config values
database = root.find(".//DatabaseName").text
server = root.find(".//SQLInstanceName").text

#build connection object
cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes')
cursor = cnxn.cursor()
cursor.execute("SELECT WSCID FROM dbo.DimDancer")
dancerids = cursor.fetchall()

# file root
fileRoot = curDirectory + '\\' + root.find(".//JsonFolder").text + '\\'
pathlist = Path(fileRoot).glob('**/*.json')

# role dictionary to use for loading
roles = {'leader': 1, 'follower': 2}

def getDancerResultsFile(filePath):

    #established connection object with database
    database = "DanceDatabase"
    server = "N-3358-W10\LATEST"
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=' + server + ';DATABASE=' + database + ';Trusted_Connection=yes')
    cursor = cnxn.cursor()

    with open(filePath,'r+') as info:
        json_data = info.read()
        dancerinfo = json.loads(json_data)

    try:
        if dancerinfo['type'] == 'dancer' and len(dancerinfo['placements']) > 0:
            wscid = dancerinfo['dancer']['wscid']
            placement = dancerinfo['placements']

            for p in placement['West Coast Swing']:
                divid = p['division']['id']
                comps = p['competitions']
                for c in comps:
                    event_month = c['event']['date'].split(' ')[0]
                    event_year = c['event']['date'].split(' ')[1]

                    try:
                        query = "INSERT INTO dbo.factEvents (wsc_id, role_id, event_id, event_month, event_year, event_points, event_result, division_id) VALUES (?,?,?,?,?,?,?,?)"
                        cursor.execute(query, wscid, roles.get(c['role']), c['event']['id'], event_month, event_year, c['points'], c['result'], divid)
                        cnxn.commit()
                    except (RuntimeError, TypeError, NameError):
                        print(query, wscid, roles.get(c['role']), c['event']['id'], event_month, event_year, c['points'], c['result'], divid)

    except :
        pass

def worker():
    while True:
        item = q.get()
        getDancerResultsFile(item)
        q.task_done()


q = queue.Queue()
for path in pathlist:
    q.put(path)

for i in range(num_threads):
    t = threading.Thread(target=worker)
    t.daemon = True
    t.start()

q.join()

print("--- %s seconds ---" % (time.time() - start_time))
