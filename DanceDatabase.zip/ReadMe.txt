Steps to load data into database

1. Unzip files to a folder on your machine
2. Add folder called DanceJson in the diretory the files were placed
3. Restore Database (DAnceDatabaseBlank.bak) into SSMS (sql server management studio) 

***it was restored in a SQL 2017 system***

Reference - https://www.mssqltips.com/sqlservertutorial/110/how-to-restore-a-sql-server-backup/

4. Update Configuration File (ConfigurationFile.xml)
	a. Enter SQLInstanceName
	b. Validate Database Name. 

5. Run Powershell Script (RunPythonFiles.ps1) from folder location of step 1

***You will be prompted to enter the file path where the python files were unzipped***
***this will run all of the python files***

Description of Python Files

1.WSCD_LoadDataInfoIntoDatabase 
- Loads Dancer Data into dbo.dimDancer table in the database
2.WSDC_CreateJsonFilesToDirectory 
- Creates a json file per dancer
3.WSDC_LoadDivisonInfo_FromFile 
- Loads a distinct list of divisions found in all of the files into dbo.dimDivision
4.WSDC_LoadEventInfo_FromFile 
- Loads a distinct list of all the event locations found in all of the files into dbo.dimEvent
5.WSDC_LoadEventResults_FromFile
- Loads all of the competitions results from all of the files into dbo.factEvents


