﻿$filePath = Read-Host "Enter Directory where python files are loaded"

Set-Location $filePath

$files = Get-ChildItem -Filter '*.py*'



$files | ForEach-Object {

    $file = $PSItem.FullName
    Write-Host "Running $file"
    python $file 

}


